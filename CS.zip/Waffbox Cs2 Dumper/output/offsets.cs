// Generated using https://github.com/a2x/cs2-dumper
// 2026-03-09 20:39:15.219671900 UTC

namespace CS2Dumper.Offsets {
    // Module: client.dll
    public static class ClientDll {
        public const nint dwCSGOInput = 0x2317FC0;
        public const nint dwEntityList = 0x24AD228;
        public const nint dwGameEntitySystem = 0x24AD228;
        public const nint dwGameEntitySystem_highestEntityIndex = 0x20A0;
        public const nint dwGameRules = 0x230BEE0;
        public const nint dwGlobalVars = 0x205C5C0;
        public const nint dwGlowManager = 0x2308CE8;
        public const nint dwLocalPlayerController = 0x22F2178;
        public const nint dwLocalPlayerPawn = 0x2067B60;
        public const nint dwPlantedC4 = 0x2315740;
        public const nint dwPrediction = 0x2067A70;
        public const nint dwSensitivity = 0x23097F8;
        public const nint dwSensitivity_sensitivity = 0x58;
        public const nint dwViewAngles = 0x2318648;
        public const nint dwViewMatrix = 0x230DF20;
        public const nint dwViewRender = 0x230E338;
        public const nint dwWeaponC4 = 0x2297380;
    }
    // Module: engine2.dll
    public static class Engine2Dll {
        public const nint dwBuildNumber = 0x60D514;
        public const nint dwNetworkGameClient = 0x908500;
        public const nint dwNetworkGameClient_clientTickCount = 0x378;
        public const nint dwNetworkGameClient_deltaTick = 0x24C;
        public const nint dwNetworkGameClient_isBackgroundMap = 0x2C141F;
        public const nint dwNetworkGameClient_localPlayer = 0xF8;
        public const nint dwNetworkGameClient_maxClients = 0x240;
        public const nint dwNetworkGameClient_serverTickCount = 0x24C;
        public const nint dwNetworkGameClient_signOnState = 0x230;
        public const nint dwWindowHeight = 0x90C8AC;
        public const nint dwWindowWidth = 0x90C8A8;
    }
    // Module: inputsystem.dll
    public static class InputsystemDll {
        public const nint dwInputSystem = 0x45AD0;
    }
    // Module: matchmaking.dll
    public static class MatchmakingDll {
        public const nint dwGameTypes = 0x1B8000;
    }
    // Module: soundsystem.dll
    public static class SoundsystemDll {
        public const nint dwSoundSystem = 0x4F3470;
        public const nint dwSoundSystem_engineViewData = 0x7C;
    }
}
